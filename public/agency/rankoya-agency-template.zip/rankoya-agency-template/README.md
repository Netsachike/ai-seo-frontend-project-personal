# Agency website template

A ready-to-publish website for agencies that sell search and AI visibility: Google rankings plus mentions in ChatGPT, Gemini, Claude and Perplexity. Made for Rankoya agency customers.

- Home page: hero with a sample client report, services, why us, process, monthly reporting, results, industries, stats, testimonials, pricing, FAQs and a contact form
- A `/pricing` page with a monthly/annual switch and a full plan comparison table
- Light and dark theme, fully responsive, keyboard and screen-reader friendly, respects reduced motion

Stack: React 19, TypeScript, Vite, Tailwind CSS 4, React Router, Lucide icons and Geist fonts. No backend is needed.

## 1. Run it locally

You need [Node.js](https://nodejs.org) 20.19 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:5173.

## 2. Make it yours

Almost everything is in **`src/config/site.ts`**:

| What                                      | Where in `site.ts`                      |
| ----------------------------------------- | --------------------------------------- |
| Agency name, logo letter, email, phone    | `SITE`                                  |
| Where "Book a call" goes (Calendly, etc.) | `SITE.bookingUrl`                       |
| Contact form destination                  | `SITE.formEndpoint`                     |
| Headline and intro                        | `HERO`                                  |
| Services, process, FAQs                   | `SERVICES`, `PROCESS`, `FAQS`           |
| Results, stats, testimonials              | `CASE_STUDIES`, `STATS`, `TESTIMONIALS` |
| The sample report in the hero             | `REPORT`                                |
| Plans, prices and comparison table        | `PLANS`, `PRICING`, `PLAN_COMPARISON`   |
| Footer links and socials                  | `FOOTER`, `SITE.socials`                |

Search the project for `[` to find every placeholder, such as `[AGENCY NAME]`, `[CLIENT 1]` and `[EMAIL]`. Also update the `<title>` and description in `index.html`.

> The numbers in `REPORT`, `CASE_STUDIES` and `STATS` are examples. Replace them with your own results, or remove them, before you publish.

**Colours.** Edit the `:root` (light) and `.dark` blocks at the top of `src/index.css`. `--ink` is the button colour, `--blue` the accent, and `--signal` the highlight.

**Logo.** Put your logo in `public/` and update `src/components/ui/logo.tsx`. Replace `public/favicon.svg` too.

**Sections.** Reorder or remove sections in `src/pages/home.tsx`.

**Contact form.** By default the form opens the visitor's email app with the message filled in. To receive submissions directly, create a free form at [Formspree](https://formspree.io), [Basin](https://usebasin.com) or similar, and paste its endpoint URL into `SITE.formEndpoint`.

**"Visibility data by Rankoya" note.** Set `SITE.poweredByRankoya` to `false` to hide it.

## 3. Publish

```bash
npm run build
```

This creates a static site in `dist/`. Host it anywhere:

- **Vercel**: import the folder or Git repo. `vercel.json` is already set up.
- **Netlify**: build command `npm run build`, publish directory `dist`. `public/_redirects` is already set up.
- **Cloudflare Pages, GitHub Pages or any static host**: upload `dist/`, and send unknown paths to `index.html` so `/pricing` works on refresh.

## Scripts

| Command           | What it does                    |
| ----------------- | ------------------------------- |
| `npm run dev`     | Start the dev server            |
| `npm run build`   | Type-check and build to `dist/` |
| `npm run preview` | Serve the built site locally    |
| `npm run lint`    | Lint with ESLint                |
| `npm run format`  | Format with Prettier            |

Platform logos (Google, ChatGPT and others) are trademarks of their owners and are used here only to show which platforms you track.
