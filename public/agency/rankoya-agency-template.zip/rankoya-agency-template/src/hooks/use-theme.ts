import { useCallback, useEffect, useState } from "react";

type Theme = "light" | "dark";

const read = (): Theme => (document.documentElement.classList.contains("dark") ? "dark" : "light");

function savedTheme() {
  try {
    return localStorage.getItem("theme");
  } catch {
    return null;
  }
}

/** Light/dark toggle. The first paint is set by the inline script in index.html. */
export function useTheme() {
  const [theme, setThemeState] = useState<Theme>(read);

  // Follow the OS setting until the visitor picks a theme themselves.
  useEffect(() => {
    const media = matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      if (savedTheme()) return;
      document.documentElement.classList.toggle("dark", media.matches);
      setThemeState(read());
    };
    media.addEventListener("change", onChange);
    return () => media.removeEventListener("change", onChange);
  }, []);

  const setTheme = useCallback((next: Theme) => {
    document.documentElement.classList.toggle("dark", next === "dark");
    try {
      localStorage.setItem("theme", next);
    } catch {
      // Storage blocked (private mode): the choice lasts for this visit only.
    }
    setThemeState(next);
  }, []);

  return { theme, setTheme };
}
