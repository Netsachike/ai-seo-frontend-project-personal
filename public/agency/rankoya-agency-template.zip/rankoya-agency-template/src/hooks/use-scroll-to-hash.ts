import { useEffect } from "react";
import { useLocation, useNavigationType } from "react-router";

/**
 * Scrolls to `#id` after navigating (e.g. "/#faq" from /pricing), or to the
 * top of a new page. Back/forward leaves the browser's own scroll restoration alone.
 */
export function useScrollToHash() {
  const { pathname, hash, key } = useLocation();
  const navigationType = useNavigationType();

  useEffect(() => {
    if (navigationType === "POP" && !hash) return;
    if (!hash) {
      window.scrollTo(0, 0);
      return;
    }
    document.getElementById(decodeURIComponent(hash.slice(1)))?.scrollIntoView();
  }, [pathname, hash, key, navigationType]);
}
