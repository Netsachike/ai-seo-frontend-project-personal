import { useEffect } from "react";
import { useLocation } from "react-router";

/**
 * Drives every `.reveal` on the page with one IntersectionObserver. Elements
 * already on screen are marked shown before hiding switches on, so nothing in
 * view flickers. Runs again on each route change.
 */
export function useReveal() {
  const { pathname } = useLocation();

  useEffect(() => {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const root = document.documentElement;
    const items = Array.from(document.querySelectorAll<HTMLElement>(".reveal:not([data-shown])"));
    for (const el of items) {
      if (el.getBoundingClientRect().top < innerHeight) el.dataset.shown = "";
    }
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          (entry.target as HTMLElement).dataset.shown = "";
          observer.unobserve(entry.target);
        }
      },
      { rootMargin: "0px 0px -10% 0px" },
    );
    for (const el of items) if (!("shown" in el.dataset)) observer.observe(el);
    root.classList.add("reveal-ready");
    return () => {
      observer.disconnect();
      root.classList.remove("reveal-ready");
    };
  }, [pathname]);
}
