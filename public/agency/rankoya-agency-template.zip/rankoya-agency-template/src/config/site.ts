/**
 * Everything you need to edit lives in this file.
 *
 * 1. Search for "[" to find every placeholder (agency name, clients, contact).
 * 2. Replace the sample numbers in `caseStudies`, `stats` and `report` with
 *    your own results. They are examples, not real figures.
 * 3. Colours and fonts live in src/index.css (the `:root` and `.dark` blocks).
 */
import type { PlatformId } from "@/lib/platforms";

export type IconName =
  | "radar"
  | "fileText"
  | "wrench"
  | "mapPin"
  | "lineChart"
  | "users"
  | "store"
  | "shoppingBag"
  | "code"
  | "briefcase"
  | "utensils"
  | "stethoscope";

export const SITE = {
  name: "[AGENCY NAME]",
  /** Shown in the logo badge. One or two letters. */
  monogram: "A",
  tagline: "Search and AI visibility for growing brands.",
  description:
    "[AGENCY NAME] gets your brand found on Google and recommended in ChatGPT, Gemini, Claude and Perplexity, then reports the results every month.",
  url: "https://example.com",
  email: "[EMAIL]",
  phone: "[PHONE NUMBER]",
  address: "[CITY, COUNTRY]",
  /** Where every "Book a call" button goes: a Calendly link, a mailto, or "/#contact" for the form. */
  bookingUrl: "/#contact",
  /**
   * Contact form: set this to a form endpoint (Formspree, Basin, your own API)
   * and the form posts JSON there. Leave it empty and the form opens the
   * visitor's email app with the message filled in instead.
   */
  formEndpoint: "",
  /** Shows a small "Visibility data by Rankoya" note in the footer. Set to false to hide it. */
  poweredByRankoya: true,
  socials: [
    { label: "LinkedIn", href: "#" },
    { label: "X", href: "#" },
    { label: "Instagram", href: "#" },
    { label: "YouTube", href: "#" },
  ],
} as const;

export const NAV = [
  { label: "Services", href: "/#services" },
  { label: "Results", href: "/#results" },
  { label: "Process", href: "/#process" },
  { label: "Pricing", href: "/pricing" },
  { label: "FAQs", href: "/#faq" },
] as const;

export const HERO = {
  pill: "Now tracking 6 AI answer engines",
  title: {
    lead: "Get found on",
    google: "Google",
    middle: "and recommended in",
    ai: "AI answers",
  },
  lead: "We measure where your brand shows up in search and AI assistants, close the gaps with content and fixes, and send you a plain report every month.",
  primaryCta: "Book a call",
  secondaryCta: "See our results",
  proof: ["No long contracts", "Monthly reporting", "You approve every change"],
} as const;

/** Engines named in the hero heading and the "we track" strip. */
export const AI_ENGINES: PlatformId[] = ["chatgpt", "claude", "gemini", "perplexity"];
export const TRACKED: PlatformId[] = ["google", "google-maps", "chatgpt", "claude", "gemini", "perplexity"];
export const CLIENTS = ["[CLIENT 1]", "[CLIENT 2]", "[CLIENT 3]", "[CLIENT 4]", "[CLIENT 5]"];

export const SERVICES_INTRO = {
  overline: "Services",
  title: "[AGENCY NAME] services",
  lead: "Everything it takes to rank in search and get cited by AI assistants, run by one team.",
};

export const SERVICES: { icon: IconName; title: string; body: string }[] = [
  {
    icon: "radar",
    title: "AI visibility audits",
    body: "We ask ChatGPT, Gemini, Claude and Perplexity the questions your buyers ask, and show which brands they recommend.",
  },
  {
    icon: "fileText",
    title: "Content that gets cited",
    body: "Articles and pages written to answer real prompts, structured so search engines and AI models can quote them.",
  },
  {
    icon: "wrench",
    title: "Technical SEO",
    body: "Site audits, schema, speed and crawl fixes. Every change is listed, approved by you, and reversible.",
  },
  {
    icon: "mapPin",
    title: "Local SEO",
    body: "Google Business Profile, reviews and local pages, so you show up in Maps and in near-me answers.",
  },
  {
    icon: "lineChart",
    title: "Rank tracking and reporting",
    body: "Daily positions on Google and weekly AI mention checks, rolled into one monthly report you can read in five minutes.",
  },
  {
    icon: "users",
    title: "Competitor analysis",
    body: "Share of voice against the three brands you lose to most, with the exact pages and prompts where they win.",
  },
];

export const COMPARISON = {
  overline: "Why us",
  title: "But, why work with us?",
  them: {
    label: "Typical SEO agencies",
    items: [
      "Report on Google rankings only",
      "Vanity metrics and long PDF decks",
      "Changes go live without your sign-off",
      "12-month lock-in contracts",
      "Content written for keywords, not questions",
    ],
  },
  us: {
    label: "[AGENCY NAME]",
    items: [
      "Track Google and 6 AI answer engines",
      "One page of numbers, then what we do next",
      "You approve every change before it ships",
      "Month-to-month, cancel any time",
      "Content written to be cited in AI answers",
    ],
  },
};

export const PROCESS_INTRO = {
  overline: "Process",
  title: "How we work",
  lead: "Four steps, repeated every month. You always know what we're doing and why.",
};

export const PROCESS = [
  {
    step: "01",
    title: "Audit",
    body: "We scan your site and run 100+ buyer prompts across AI engines to set your starting visibility score.",
  },
  {
    step: "02",
    title: "Plan",
    body: "You get a ranked action plan: what we'll fix, what we'll write, and what we need from you.",
  },
  {
    step: "03",
    title: "Publish",
    body: "We write and fix. Nothing goes live until you approve it, and every change can be rolled back.",
  },
  {
    step: "04",
    title: "Report",
    body: "A monthly report on rankings, AI mentions and leads, with next month's plan attached.",
  },
] as const;

/**
 * The sample client report shown in the hero and the report section.
 * Swap these figures for a real (anonymised) client of yours.
 */
export const REPORT = {
  client: "[CLIENT NAME]",
  period: "Last 6 months",
  score: 68,
  scoreDelta: 23,
  trend: [45, 47, 52, 55, 61, 68],
  months: ["May", "Jun", "Jul", "Aug", "Sep", "Oct"],
  engines: [
    { id: "chatgpt", mentions: 74 },
    { id: "gemini", mentions: 66 },
    { id: "perplexity", mentions: 58 },
    { id: "claude", mentions: 51 },
  ] as { id: PlatformId; mentions: number }[],
  shareOfVoice: [
    { name: "[CLIENT NAME]", value: 34, you: true },
    { name: "[COMPETITOR 1]", value: 27 },
    { name: "[COMPETITOR 2]", value: 21 },
    { name: "[COMPETITOR 3]", value: 18 },
  ],
};

export const REPORT_SECTION = {
  overline: "Reporting",
  title: "One report. Numbers first, then what we do next.",
  lead: "Every month you get your visibility score, where AI assistants mention you, how you compare with competitors, and the actions we'll take.",
  points: [
    "AI visibility score across 6 engines",
    "Google rankings for your tracked keywords",
    "Share of voice against your top competitors",
    "What we shipped, and what's next",
  ],
};

export const CASE_STUDIES_INTRO = {
  overline: "Results",
  title: "Brands we've grown",
  linkLabel: "See all work",
};

/** Sample results. Replace with your own clients before you publish. */
export const CASE_STUDIES = [
  {
    title: "[CASE 1 TITLE]",
    sector: "Specialty coffee, e-commerce",
    metric: "+41%",
    metricLabel: "AI visibility score in 4 months",
    body: "From zero ChatGPT mentions to the second brand recommended for its core category.",
  },
  {
    title: "[CASE 2 TITLE]",
    sector: "Dental clinic group, local",
    metric: "3.1x",
    metricLabel: "Booking calls from Google Maps",
    body: "Rebuilt location pages and review flow across 6 clinics.",
  },
  {
    title: "[CASE 3 TITLE]",
    sector: "B2B software, SaaS",
    metric: "+212%",
    metricLabel: "Organic sign-ups year on year",
    body: "Comparison and how-to content now cited by Perplexity and AI Overviews.",
  },
  {
    title: "[CASE 4 TITLE]",
    sector: "Boutique hotel, hospitality",
    metric: "#1",
    metricLabel: "Gemini answer for its city and category",
    body: "Structured data and local content that AI assistants could finally read.",
  },
];

export const INDUSTRIES_INTRO = {
  overline: "Who we help",
  title: "Built for brands people search for",
};

export const INDUSTRIES: { icon: IconName; title: string; body: string }[] = [
  { icon: "store", title: "Local businesses", body: "Win the map pack and near-me answers in your area." },
  { icon: "shoppingBag", title: "E-commerce", body: "Get products recommended when shoppers ask AI what to buy." },
  { icon: "code", title: "SaaS", body: "Show up in best-tool and comparison answers your buyers read." },
  { icon: "briefcase", title: "Professional services", body: "Be the firm AI assistants name for your speciality." },
  { icon: "utensils", title: "Hospitality", body: "Fill tables and rooms from Maps, reviews and AI travel answers." },
  { icon: "stethoscope", title: "Healthcare", body: "Accurate, trusted visibility for clinics and practices." },
];

/** The stats band. Set each value to your own numbers. */
export const STATS = [
  { value: 120, suffix: "+", label: "Brands tracked" },
  { value: 4800, suffix: "+", label: "Articles published" },
  { value: 38, suffix: "%", label: "Average visibility gain" },
  { value: 6, suffix: "", label: "AI engines monitored" },
];

export const TESTIMONIALS_INTRO = {
  overline: "Testimonials",
  title: "What clients say",
};

export const TESTIMONIALS = [
  {
    quote: "[Client quote. One or two sentences on the result you delivered and what it meant for their business.]",
    name: "[CLIENT NAME]",
    role: "[ROLE, COMPANY]",
  },
  {
    quote: "[Client quote. Mention a number if you can: leads, bookings, rankings or AI mentions.]",
    name: "[CLIENT NAME]",
    role: "[ROLE, COMPANY]",
  },
  {
    quote: "[Client quote. Something about how easy you are to work with and how clear the reporting is.]",
    name: "[CLIENT NAME]",
    role: "[ROLE, COMPANY]",
  },
];

export type Plan = {
  id: string;
  name: string;
  monthly: number;
  annual: number;
  blurb: string;
  features: string[];
  featured?: boolean;
  cta: string;
};

export const PRICING = {
  overline: "Pricing",
  title: "Simple monthly plans",
  lead: "Month-to-month. Change or cancel any time.",
  currency: "$",
  annualNote: "2 months free",
  compareLabel: "Compare all plan features",
  customTitle: "Need something bigger?",
  customBody: "Multi-location brands, franchises and in-house teams get a custom scope and price.",
  customCta: "Talk to us",
};

export const PLANS: Plan[] = [
  {
    id: "starter",
    name: "Starter",
    monthly: 900,
    annual: 750,
    blurb: "For one location or a small site getting started.",
    features: [
      "AI visibility audit",
      "50 tracked keywords",
      "2 articles per month",
      "Google Business Profile setup",
      "Monthly report",
    ],
    cta: "Get started",
  },
  {
    id: "growth",
    name: "Growth",
    monthly: 1900,
    annual: 1580,
    blurb: "For brands ready to win in search and AI answers.",
    features: [
      "Everything in Starter",
      "200 tracked keywords",
      "6 articles per month",
      "Technical SEO fixes",
      "Competitor share of voice",
      "Fortnightly check-in call",
    ],
    featured: true,
    cta: "Book a call",
  },
  {
    id: "scale",
    name: "Scale",
    monthly: 3900,
    annual: 3250,
    blurb: "For multi-location and high-competition markets.",
    features: [
      "Everything in Growth",
      "Unlimited tracked keywords",
      "12 articles per month",
      "Local pages for every location",
      "Digital PR and link building",
      "Dedicated strategist",
    ],
    cta: "Book a call",
  },
];

/** Rows of the comparison table on /pricing. `true` = included, a string = the amount. */
export const PLAN_COMPARISON: { group: string; rows: { label: string; values: (string | boolean)[] }[] }[] = [
  {
    group: "Visibility",
    rows: [
      { label: "AI engines tracked", values: ["6", "6", "6"] },
      { label: "Tracked keywords", values: ["50", "200", "Unlimited"] },
      { label: "Buyer prompts monitored", values: ["50", "150", "400"] },
      { label: "Competitor share of voice", values: [false, true, true] },
    ],
  },
  {
    group: "Content",
    rows: [
      { label: "Articles per month", values: ["2", "6", "12"] },
      { label: "Location pages", values: [false, "Up to 5", "Unlimited"] },
      { label: "Digital PR and link building", values: [false, false, true] },
    ],
  },
  {
    group: "Technical",
    rows: [
      { label: "Site audit", values: ["Quarterly", "Monthly", "Monthly"] },
      { label: "Technical fixes", values: [false, true, true] },
      { label: "Schema and structured data", values: [true, true, true] },
    ],
  },
  {
    group: "Support",
    rows: [
      { label: "Monthly report", values: [true, true, true] },
      { label: "Check-in calls", values: ["Monthly", "Fortnightly", "Weekly"] },
      { label: "Dedicated strategist", values: [false, false, true] },
    ],
  },
];

export const FAQ_INTRO = {
  overline: "FAQs",
  title: "Frequently asked questions",
};

export const FAQS = [
  {
    q: "What is AI visibility, and why does it matter?",
    a: "More buyers now ask ChatGPT, Gemini or Perplexity before they search Google. AI visibility is how often those assistants mention or recommend your brand. If they don't name you, you're not on the shortlist.",
  },
  {
    q: "How do you measure where we show up in AI answers?",
    a: "We run a fixed set of buyer prompts across each engine every week and record which brands are mentioned, in what order, and which pages are cited. That becomes your visibility score.",
  },
  {
    q: "Do you still do traditional SEO?",
    a: "Yes. Google rankings, technical fixes and local SEO are part of every plan. The same work that ranks on Google is what AI assistants read and quote.",
  },
  {
    q: "Will you change our website without asking?",
    a: "No. Every article and fix is sent to you for approval first, and every change can be rolled back.",
  },
  {
    q: "How soon will we see results?",
    a: "Most clients see AI mentions move within 6 to 10 weeks and Google rankings within 3 to 6 months. You'll see the trend in your first monthly report.",
  },
  {
    q: "Is there a long contract?",
    a: "No. Plans are month-to-month. Annual billing is optional and comes with two months free.",
  },
];

export const CONTACT = {
  overline: "Contact",
  title: "Ready to see where your brand shows up?",
  lead: "Book a free 30-minute visibility review. We'll show you how you rank on Google and in AI answers, and what we'd do first.",
  responseNote: "We reply within one business day.",
  form: {
    name: "Your name",
    email: "Work email",
    website: "Website",
    message: "What would you like to grow?",
    submit: "Send message",
    sending: "Sending",
    success: "Thanks. We'll be in touch within one business day.",
    error: "Something went wrong. Please email us instead.",
  },
};

export const FOOTER = {
  columns: [
    {
      title: "Services",
      links: [
        { label: "AI visibility audits", href: "/#services" },
        { label: "Content", href: "/#services" },
        { label: "Technical SEO", href: "/#services" },
        { label: "Local SEO", href: "/#services" },
      ],
    },
    {
      title: "Company",
      links: [
        { label: "Results", href: "/#results" },
        { label: "Process", href: "/#process" },
        { label: "Testimonials", href: "/#testimonials" },
        { label: "Contact", href: "/#contact" },
      ],
    },
    {
      title: "Resources",
      links: [
        { label: "Pricing", href: "/pricing" },
        { label: "FAQs", href: "/#faq" },
        { label: "Sample report", href: "/#report" },
      ],
    },
    {
      title: "Legal",
      links: [
        { label: "Privacy policy", href: "#" },
        { label: "Terms of service", href: "#" },
        { label: "Cookies", href: "#" },
      ],
    },
  ],
};
