import { useState } from "react";
import { ArrowRight, Clock, Mail, MapPin, Phone } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Container } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { CONTACT, SITE } from "@/config/site";

type Status = "idle" | "sending" | "sent" | "error";

const FIELD =
  "w-full rounded-xl border border-border bg-bg px-4 py-3 text-[15px] text-fg placeholder:text-fg-3 transition-colors hover:border-border-strong focus:border-blue focus:outline-none focus-visible:outline-2 focus-visible:outline-offset-0 focus-visible:outline-blue";

/** Closing call to action with the contact form, on the fixed-dark panel. */
export function Contact() {
  const [status, setStatus] = useState<Status>("idle");
  const { form } = CONTACT;

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formEl = event.currentTarget;
    const data = Object.fromEntries(new FormData(formEl)) as Record<string, string>;

    // No endpoint configured: hand the message to the visitor's email app.
    if (!SITE.formEndpoint) {
      const body = `${data.message}\n\n${data.name}\n${data.email}\n${data.website}`;
      window.location.href = `mailto:${SITE.email}?subject=${encodeURIComponent(
        `Enquiry from ${data.name}`,
      )}&body=${encodeURIComponent(body)}`;
      return;
    }

    setStatus("sending");
    try {
      const res = await fetch(SITE.formEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error(String(res.status));
      setStatus("sent");
      formEl.reset();
    } catch {
      setStatus("error");
    }
  }

  return (
    <section id="contact" aria-labelledby="contact-heading" className="py-20 sm:py-24 lg:py-28">
      <Container>
        <Reveal>
          <div className="relative isolate overflow-hidden rounded-[28px] bg-midnight p-6 ring-1 ring-white/5 sm:p-10 lg:p-14">
            <div
              aria-hidden
              className="absolute inset-0 -z-10 bg-grid [mask-image:radial-gradient(ellipse_60%_70%_at_20%_40%,black,transparent)] [--grid-line:rgb(255_255_255/0.05)]"
            />
            <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
              <div>
                <p className="text-overline text-[#a9c1ff]">{CONTACT.overline}</p>
                <h2 id="contact-heading" className="mt-3 text-section text-white">
                  {CONTACT.title}
                </h2>
                <p className="mt-4 text-lead text-nav-fg">{CONTACT.lead}</p>
                <ul className="mt-8 space-y-4 text-[15px] text-nav-fg">
                  <li className="flex items-center gap-3">
                    <Mail aria-hidden className="size-4 shrink-0 text-[#a9c1ff]" />
                    <a href={`mailto:${SITE.email}`} className="hover:text-white hover:underline">
                      {SITE.email}
                    </a>
                  </li>
                  <li className="flex items-center gap-3">
                    <Phone aria-hidden className="size-4 shrink-0 text-[#a9c1ff]" />
                    <a href={`tel:${SITE.phone.replace(/[^\d+]/g, "")}`} className="hover:text-white hover:underline">
                      {SITE.phone}
                    </a>
                  </li>
                  <li className="flex items-center gap-3">
                    <MapPin aria-hidden className="size-4 shrink-0 text-[#a9c1ff]" />
                    {SITE.address}
                  </li>
                  <li className="flex items-center gap-3">
                    <Clock aria-hidden className="size-4 shrink-0 text-[#a9c1ff]" />
                    {CONTACT.responseNote}
                  </li>
                </ul>
              </div>

              <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-surface p-5 sm:p-7">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label={form.name}>
                    <input name="name" required autoComplete="name" className={FIELD} />
                  </Field>
                  <Field label={form.email}>
                    <input name="email" type="email" required autoComplete="email" className={FIELD} />
                  </Field>
                  <Field label={form.website} className="sm:col-span-2">
                    <input
                      name="website"
                      type="url"
                      inputMode="url"
                      placeholder="https://"
                      autoComplete="url"
                      className={FIELD}
                    />
                  </Field>
                  <Field label={form.message} className="sm:col-span-2">
                    <textarea name="message" rows={4} required className={`${FIELD} resize-y`} />
                  </Field>
                </div>
                <Button type="submit" size="lg" className="mt-6 w-full" disabled={status === "sending"}>
                  {status === "sending" ? form.sending : form.submit}
                  <ArrowRight aria-hidden />
                </Button>
                <p role="status" aria-live="polite" className="mt-3 min-h-5 text-center text-[14px]">
                  {status === "sent" && <span className="text-success">{form.success}</span>}
                  {status === "error" && <span className="text-danger">{form.error}</span>}
                </p>
              </form>
            </div>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}

function Field({ label, className, children }: { label: string; className?: string; children: React.ReactNode }) {
  return (
    <label className={`flex flex-col gap-1.5 ${className ?? ""}`}>
      <span className="text-[14px] font-medium text-fg">{label}</span>
      {children}
    </label>
  );
}
