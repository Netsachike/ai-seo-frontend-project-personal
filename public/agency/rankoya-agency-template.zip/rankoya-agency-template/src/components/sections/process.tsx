import { Container, Section, SectionHeading } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { PROCESS, PROCESS_INTRO } from "@/config/site";

export function Process() {
  return (
    <Section id="process" aria-labelledby="process-heading">
      <Container>
        <Reveal>
          <SectionHeading id="process-heading" {...PROCESS_INTRO} />
        </Reveal>
        <ol className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {PROCESS.map((item, i) => (
            <Reveal as="li" key={item.step} delay={i * 0.06} className="relative">
              <div className="h-full rounded-2xl border border-border bg-surface p-6 shadow-card">
                <div className="flex items-center gap-3">
                  <span className="grid size-10 place-items-center rounded-full bg-ink num text-[14px] font-medium text-ink-fg">
                    {item.step}
                  </span>
                  {i < PROCESS.length - 1 && (
                    <span aria-hidden className="hidden h-px flex-1 bg-border-strong lg:block" />
                  )}
                </div>
                <h3 className="mt-6 text-h2 text-fg">{item.title}</h3>
                <p className="mt-2 text-[15px] leading-6 text-fg-2">{item.body}</p>
              </div>
            </Reveal>
          ))}
        </ol>
      </Container>
    </Section>
  );
}
