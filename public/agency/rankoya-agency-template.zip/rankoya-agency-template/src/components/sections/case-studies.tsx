import { ArrowRight, ArrowUpRight } from "lucide-react";

import { Container, Section, SectionHeading } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { SmartLink } from "@/components/ui/smart-link";
import { CASE_STUDIES, CASE_STUDIES_INTRO } from "@/config/site";

export function CaseStudies() {
  return (
    <Section id="results" aria-labelledby="results-heading" className="border-t border-border bg-surface">
      <Container>
        <Reveal className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <SectionHeading
            id="results-heading"
            align="start"
            overline={CASE_STUDIES_INTRO.overline}
            title={CASE_STUDIES_INTRO.title}
          />
          <SmartLink
            href="#"
            className="group inline-flex shrink-0 items-center gap-1.5 text-[15px] font-medium text-blue hover:underline"
          >
            {CASE_STUDIES_INTRO.linkLabel}
            <ArrowRight aria-hidden className="size-4 transition-transform group-hover:translate-x-0.5" />
          </SmartLink>
        </Reveal>

        <ul className="mt-12 grid gap-4 md:grid-cols-2">
          {CASE_STUDIES.map((study, i) => (
            <Reveal as="li" key={study.title} delay={(i % 2) * 0.06}>
              <a
                href="#"
                className="group flex h-full flex-col rounded-2xl border border-border bg-bg p-6 transition-colors hover:border-border-strong sm:p-8"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-[13px] text-fg-3">{study.sector}</p>
                    <h3 className="mt-1 text-h2 text-fg">{study.title}</h3>
                  </div>
                  <span
                    aria-hidden
                    className="grid size-9 shrink-0 place-items-center rounded-full border border-border text-fg-2 transition-colors group-hover:border-ink group-hover:bg-ink group-hover:text-ink-fg"
                  >
                    <ArrowUpRight className="size-4" />
                  </span>
                </div>
                <div className="mt-8 flex flex-wrap items-baseline gap-x-3 gap-y-1">
                  <p className="text-metric-xl text-fg">{study.metric}</p>
                  <p className="text-[14px] font-medium text-fg-2">{study.metricLabel}</p>
                </div>
                <p className="mt-4 text-[15px] leading-6 text-fg-2">{study.body}</p>
              </a>
            </Reveal>
          ))}
        </ul>
      </Container>
    </Section>
  );
}
