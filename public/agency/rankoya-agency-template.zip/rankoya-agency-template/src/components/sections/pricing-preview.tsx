import { ArrowRight } from "lucide-react";
import { Link } from "react-router";

import { PlanCards } from "@/components/sections/plan-cards";
import { Container, Section, SectionHeading } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { PRICING } from "@/config/site";

export function PricingPreview() {
  return (
    <Section id="pricing" aria-labelledby="pricing-heading">
      <Container>
        <Reveal>
          <SectionHeading id="pricing-heading" overline={PRICING.overline} title={PRICING.title} lead={PRICING.lead} />
        </Reveal>
        <div className="mt-10">
          <PlanCards />
        </div>
        <div className="mt-8 text-center">
          <Link
            to="/pricing"
            className="group inline-flex items-center gap-1.5 text-[15px] font-medium text-blue hover:underline"
          >
            {PRICING.compareLabel}
            <ArrowRight aria-hidden className="size-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </div>
      </Container>
    </Section>
  );
}
