import { useState } from "react";
import { Check } from "lucide-react";

import { ButtonLink } from "@/components/ui/button";
import { Reveal } from "@/components/ui/reveal";
import { PLANS, PRICING, SITE } from "@/config/site";
import { cn } from "@/lib/cn";

type Billing = "monthly" | "annual";

/** Monthly/annual switch plus the three plan cards. */
export function PlanCards() {
  const [billing, setBilling] = useState<Billing>("monthly");

  return (
    <div>
      <div className="flex justify-center">
        <div
          role="radiogroup"
          aria-label="Billing period"
          className="inline-flex rounded-full border border-border bg-surface p-1"
        >
          {(["monthly", "annual"] as const).map((option) => (
            <button
              key={option}
              type="button"
              role="radio"
              aria-checked={billing === option}
              onClick={() => setBilling(option)}
              className={cn(
                "press inline-flex h-9 items-center gap-2 rounded-full px-4 text-[14px] font-medium",
                billing === option ? "bg-ink text-ink-fg" : "text-fg-2 hover:text-fg",
              )}
            >
              {option === "monthly" ? "Monthly" : "Annual"}
              {option === "annual" && (
                <span
                  className={cn(
                    "rounded-full px-1.5 py-px text-[11px] font-semibold",
                    billing === option ? "bg-white/20 text-ink-fg" : "bg-success-bg text-success",
                  )}
                >
                  {PRICING.annualNote}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      <ul className="mt-10 grid gap-4 lg:grid-cols-3">
        {PLANS.map((plan, i) => {
          const price = billing === "monthly" ? plan.monthly : plan.annual;
          return (
            <Reveal
              as="li"
              key={plan.id}
              delay={i * 0.06}
              className={cn(
                "relative flex flex-col rounded-2xl border bg-surface p-6 sm:p-8",
                plan.featured ? "border-ink shadow-pop ring-1 ring-ink" : "border-border shadow-card",
              )}
            >
              {plan.featured && (
                <span className="absolute -top-3 left-6 rounded-full bg-signal px-2.5 py-0.5 text-caption text-signal-ink">
                  Most popular
                </span>
              )}
              <h3 className="text-h2 text-fg">{plan.name}</h3>
              <p className="mt-2 min-h-12 text-[14px] leading-[22px] text-fg-2">{plan.blurb}</p>
              <p className="mt-6 flex items-baseline gap-1.5">
                <span className="text-metric-xl text-fg">
                  {PRICING.currency}
                  {price.toLocaleString("en")}
                </span>
                <span className="text-[14px] text-fg-3">/month</span>
              </p>
              <p className="mt-1 h-5 text-[13px] text-fg-3">
                {billing === "annual" ? "Billed annually" : "Billed monthly, cancel any time"}
              </p>
              <ButtonLink href={SITE.bookingUrl} variant={plan.featured ? "primary" : "secondary"} className="mt-6">
                {plan.cta}
              </ButtonLink>
              <ul className="mt-8 space-y-3 border-t border-border pt-6">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3 text-[14px] text-fg-2">
                    <Check aria-hidden className="mt-0.5 size-4 shrink-0 text-blue" strokeWidth={2.5} />
                    {feature}
                  </li>
                ))}
              </ul>
            </Reveal>
          );
        })}
      </ul>
    </div>
  );
}
