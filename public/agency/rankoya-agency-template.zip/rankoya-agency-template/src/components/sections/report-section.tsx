import { Check } from "lucide-react";

import { EngineBars, SampleChip, ScoreChart, ScoreHeadline, ShareOfVoice } from "@/components/mockups/report-parts";
import { Container, Section } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { REPORT, REPORT_SECTION } from "@/config/site";

/** The monthly report, shown as a dashboard on the fixed-dark panel. */
export function ReportSection() {
  return (
    <Section id="report" aria-labelledby="report-heading" className="pt-0 sm:pt-0 lg:pt-0">
      <Container>
        <Reveal>
          <div className="relative isolate overflow-hidden rounded-[28px] bg-midnight p-6 ring-1 ring-white/5 sm:p-10 lg:p-14">
            <div
              aria-hidden
              className="absolute inset-0 -z-10 bg-grid [mask-image:radial-gradient(ellipse_60%_70%_at_30%_30%,black,transparent)] [--grid-line:rgb(255_255_255/0.05)]"
            />
            <div className="grid gap-10 lg:grid-cols-[1fr_1.25fr] lg:gap-14">
              <div>
                <p className="text-overline text-[#a9c1ff]">{REPORT_SECTION.overline}</p>
                <h2 id="report-heading" className="mt-3 text-section text-white">
                  {REPORT_SECTION.title}
                </h2>
                <p className="mt-4 text-lead text-nav-fg">{REPORT_SECTION.lead}</p>
                <ul className="mt-8 space-y-3">
                  {REPORT_SECTION.points.map((point) => (
                    <li key={point} className="flex items-start gap-3 text-[15px] text-nav-fg">
                      <Check aria-hidden className="mt-0.5 size-4 shrink-0 text-[#a9c1ff]" strokeWidth={2.5} />
                      {point}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl border border-border bg-surface p-5 sm:col-span-2">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-overline text-fg-3">Visibility score</p>
                      <p className="mt-1 text-h3 text-fg">{REPORT.client}</p>
                    </div>
                    <SampleChip />
                  </div>
                  <div className="mt-3 grid items-end gap-4 sm:grid-cols-[auto_1fr]">
                    <ScoreHeadline />
                    <ScoreChart />
                  </div>
                </div>
                <div className="rounded-2xl border border-border bg-surface p-5">
                  <p className="mb-4 text-[13px] font-medium text-fg-2">AI engine mentions</p>
                  <EngineBars />
                </div>
                <div className="rounded-2xl border border-border bg-surface p-5">
                  <p className="mb-4 text-[13px] font-medium text-fg-2">Share of voice</p>
                  <ShareOfVoice />
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </Container>
    </Section>
  );
}
