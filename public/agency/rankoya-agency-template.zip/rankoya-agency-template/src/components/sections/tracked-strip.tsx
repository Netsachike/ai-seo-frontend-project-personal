import { Container } from "@/components/ui/container";
import { PlatformIcon } from "@/components/ui/platform-icon";
import { CLIENTS, SITE, TRACKED } from "@/config/site";
import { PLATFORMS } from "@/lib/platforms";

/** The engines you track, then a scrolling row of client names. */
export function TrackedStrip() {
  return (
    <section aria-labelledby="tracked-heading" className="border-y border-border bg-surface py-12">
      <Container>
        <h2 id="tracked-heading" className="text-center text-[15px] font-medium text-fg-2">
          {SITE.name} tracks and grows your visibility across
        </h2>
        <ul className="mt-6 flex flex-wrap justify-center gap-2.5">
          {TRACKED.map((id) => (
            <li
              key={id}
              className="inline-flex items-center gap-2 rounded-full border border-border bg-bg py-1.5 ps-1.5 pe-3.5 text-[14px] font-medium text-fg"
            >
              <PlatformIcon id={id} size={24} decorative />
              {PLATFORMS[id].name}
            </li>
          ))}
        </ul>
      </Container>

      <div className="marquee marquee-mask mt-10 overflow-hidden">
        <p className="sr-only">Clients: {CLIENTS.join(", ")}</p>
        <div aria-hidden className="marquee-track flex w-max">
          {[0, 1].map((copy) => (
            <ul key={copy} className={copy ? "marquee-copy flex shrink-0" : "flex shrink-0"}>
              {CLIENTS.map((client) => (
                <li
                  key={client}
                  className="px-8 text-[20px] font-semibold tracking-[-0.02em] whitespace-nowrap text-fg-3 sm:px-12"
                >
                  {client}
                </li>
              ))}
            </ul>
          ))}
        </div>
      </div>
    </section>
  );
}
