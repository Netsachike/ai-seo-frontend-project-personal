import { Container } from "@/components/ui/container";
import { STATS } from "@/config/site";
import { useCountUp } from "@/hooks/use-count-up";

export function Stats() {
  return (
    <section aria-label="Results in numbers" className="pb-20 sm:pb-24 lg:pb-28">
      <Container>
        <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border bg-border lg:grid-cols-4">
          {STATS.map((stat) => (
            <Stat key={stat.label} {...stat} />
          ))}
        </dl>
      </Container>
    </section>
  );
}

function Stat({ value, suffix, label }: { value: number; suffix: string; label: string }) {
  const { ref, value: shown } = useCountUp<HTMLElement>(value);
  return (
    <div className="flex flex-col-reverse gap-2 bg-surface p-6 sm:p-8">
      <dt className="text-[14px] text-fg-2">{label}</dt>
      <dd ref={ref} className="text-metric-xl text-fg" aria-label={`${value.toLocaleString("en")}${suffix}`}>
        <span aria-hidden>
          {shown.toLocaleString("en")}
          {suffix}
        </span>
      </dd>
    </div>
  );
}
