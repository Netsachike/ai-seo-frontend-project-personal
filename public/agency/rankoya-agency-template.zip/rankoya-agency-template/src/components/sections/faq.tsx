import { Plus } from "lucide-react";

import { Container, Section, SectionHeading } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { FAQ_INTRO, FAQS } from "@/config/site";
import { cn } from "@/lib/cn";

/** Native <details> accordion: works without JavaScript and animates where supported. */
export function Faq({ className }: { className?: string }) {
  return (
    <Section id="faq" aria-labelledby="faq-heading" className={cn("border-t border-border bg-surface", className)}>
      <Container className="grid gap-10 lg:grid-cols-[1fr_1.6fr] lg:gap-16">
        <Reveal>
          <SectionHeading id="faq-heading" align="start" {...FAQ_INTRO} />
        </Reveal>
        <Reveal delay={0.06}>
          <ul className="divide-y divide-border border-y border-border">
            {FAQS.map((item) => (
              <li key={item.q}>
                <details name="faq" className="faq-item group">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-6 py-5 text-[17px] font-medium text-fg [&::-webkit-details-marker]:hidden">
                    {item.q}
                    <Plus
                      aria-hidden
                      className="size-5 shrink-0 text-fg-3 transition-transform duration-200 group-open:rotate-45"
                    />
                  </summary>
                  <p className="pe-10 pb-6 text-[15px] leading-6 text-fg-2">{item.a}</p>
                </details>
              </li>
            ))}
          </ul>
        </Reveal>
      </Container>
    </Section>
  );
}
