import { ArrowRight, Check } from "lucide-react";

import { ReportCard } from "@/components/mockups/report-card";
import { ButtonLink } from "@/components/ui/button";
import { Container } from "@/components/ui/container";
import { PlatformIcon } from "@/components/ui/platform-icon";
import { AI_ENGINES, HERO, SITE } from "@/config/site";
import type { PlatformId } from "@/lib/platforms";

/** Unanimated on purpose: the heading is the first thing to paint. */
export function Hero() {
  const { title } = HERO;
  return (
    <section aria-labelledby="hero-heading" className="relative isolate overflow-hidden">
      <div
        aria-hidden
        className="absolute inset-0 -z-10 bg-grid [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,black,transparent)] opacity-70"
      />

      <Container className="grid items-center gap-14 pt-12 pb-20 sm:pt-16 lg:grid-cols-[1.15fr_1fr] lg:gap-12 lg:pt-20 lg:pb-28">
        <div className="text-center lg:text-start">
          <p className="inline-flex max-w-full items-center gap-2.5 rounded-full border border-border bg-surface py-1.5 ps-2.5 pe-3.5 text-[13px] font-medium text-fg-2 shadow-card sm:text-[14px]">
            <span aria-hidden className="size-2 shrink-0 rounded-full bg-signal" />
            <span className="truncate">{HERO.pill}</span>
          </p>

          <h1 id="hero-heading" className="mx-auto mt-7 max-w-[16ch] text-hero text-fg lg:mx-0">
            {title.lead}{" "}
            <span className="whitespace-nowrap">
              <InlineIcons ids={["google"]} />
              {title.google}
            </span>{" "}
            <span className="text-fg-3">{title.middle}</span>{" "}
            <span className="whitespace-nowrap">
              <InlineIcons ids={AI_ENGINES} />
              {title.ai}
            </span>
          </h1>

          <p className="mx-auto mt-6 max-w-xl text-lead text-fg-2 lg:mx-0">{HERO.lead}</p>

          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row lg:justify-start">
            <ButtonLink href={SITE.bookingUrl} size="lg" className="w-full sm:w-auto sm:min-w-44">
              {HERO.primaryCta}
              <ArrowRight aria-hidden />
            </ButtonLink>
            <ButtonLink href="/#results" variant="secondary" size="lg" className="w-full sm:w-auto">
              {HERO.secondaryCta}
            </ButtonLink>
          </div>

          <ul className="mt-9 flex flex-col items-center gap-x-6 gap-y-2.5 text-[14px] text-fg-2 sm:flex-row sm:flex-wrap sm:justify-center lg:justify-start">
            {HERO.proof.map((item) => (
              <li key={item} className="flex items-center gap-2">
                <Check aria-hidden className="size-4 text-blue" strokeWidth={2.5} />
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="mx-auto w-full max-w-md lg:max-w-none">
          <ReportCard />
        </div>
      </Container>
    </section>
  );
}

/** Overlapping engine marks set inline in the heading, sized to the cap height. */
function InlineIcons({ ids }: { ids: PlatformId[] }) {
  return (
    <span aria-hidden className="me-[0.18em] inline-flex -translate-y-[0.06em] align-middle">
      {ids.map((id, i) => (
        <span
          key={id}
          className="inline-flex rounded-[0.24em] ring-[0.06em] ring-bg"
          style={{ marginInlineStart: i === 0 ? 0 : "-0.22em", zIndex: ids.length - i }}
        >
          <PlatformIcon id={id} size={64} decorative className="size-[0.82em]" />
        </span>
      ))}
    </span>
  );
}
