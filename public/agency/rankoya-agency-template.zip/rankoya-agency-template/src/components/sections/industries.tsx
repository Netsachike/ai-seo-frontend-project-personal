import { Container, Section, SectionHeading } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { INDUSTRIES, INDUSTRIES_INTRO } from "@/config/site";
import { ICONS } from "@/lib/icons";

export function Industries() {
  return (
    <Section aria-labelledby="industries-heading">
      <Container>
        <Reveal>
          <SectionHeading id="industries-heading" {...INDUSTRIES_INTRO} />
        </Reveal>
        <ul className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {INDUSTRIES.map((industry) => {
            const Icon = ICONS[industry.icon];
            return (
              <li key={industry.title} className="flex gap-4 bg-surface p-6">
                <Icon aria-hidden className="mt-0.5 size-5 shrink-0 text-blue" />
                <div>
                  <h3 className="text-h3 text-fg">{industry.title}</h3>
                  <p className="mt-1 text-[14px] leading-[22px] text-fg-2">{industry.body}</p>
                </div>
              </li>
            );
          })}
        </ul>
      </Container>
    </Section>
  );
}
