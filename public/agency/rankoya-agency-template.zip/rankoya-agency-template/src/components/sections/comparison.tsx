import { Check, Minus } from "lucide-react";

import { Container, Section, SectionHeading } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { COMPARISON } from "@/config/site";

export function Comparison() {
  return (
    <Section aria-labelledby="comparison-heading" className="border-t border-border bg-surface">
      <Container>
        <Reveal>
          <SectionHeading id="comparison-heading" overline={COMPARISON.overline} title={COMPARISON.title} />
        </Reveal>
        <div className="mx-auto mt-12 grid max-w-4xl gap-4 md:grid-cols-2">
          <Reveal className="rounded-2xl border border-border bg-bg p-6 sm:p-8">
            <h3 className="text-h2 text-fg-2">{COMPARISON.them.label}</h3>
            <ul className="mt-6 space-y-4">
              {COMPARISON.them.items.map((item) => (
                <li key={item} className="flex items-start gap-3 text-[15px] text-fg-2">
                  <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-surface-2 text-fg-3">
                    <Minus aria-hidden className="size-3" strokeWidth={3} />
                  </span>
                  {item}
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal
            delay={0.08}
            className="relative rounded-2xl border border-ink bg-surface p-6 shadow-pop ring-1 ring-ink sm:p-8"
          >
            <h3 className="text-h2 text-fg">{COMPARISON.us.label}</h3>
            <ul className="mt-6 space-y-4">
              {COMPARISON.us.items.map((item) => (
                <li key={item} className="flex items-start gap-3 text-[15px] text-fg">
                  <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-ink text-ink-fg">
                    <Check aria-hidden className="size-3" strokeWidth={3} />
                  </span>
                  {item}
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </Container>
    </Section>
  );
}
