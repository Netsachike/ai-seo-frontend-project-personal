import { Container, Section, SectionHeading } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { TESTIMONIALS, TESTIMONIALS_INTRO } from "@/config/site";

export function Testimonials() {
  return (
    <Section id="testimonials" aria-labelledby="testimonials-heading" className="border-t border-border bg-surface">
      <Container>
        <Reveal>
          <SectionHeading id="testimonials-heading" {...TESTIMONIALS_INTRO} />
        </Reveal>
        <ul className="mt-12 grid gap-4 lg:grid-cols-3">
          {TESTIMONIALS.map((item, i) => (
            <Reveal as="li" key={i} delay={i * 0.06}>
              <figure className="flex h-full flex-col rounded-2xl border border-border bg-bg p-6 sm:p-8">
                <blockquote className="flex-1 text-[17px] leading-7 text-fg">“{item.quote}”</blockquote>
                <figcaption className="mt-8 flex items-center gap-3">
                  <span
                    aria-hidden
                    className="grid size-10 place-items-center rounded-full bg-blue-bg text-[14px] font-semibold text-blue-ink"
                  >
                    {initials(item.name)}
                  </span>
                  <span>
                    <span className="block text-h3 text-fg">{item.name}</span>
                    <span className="block text-[13px] text-fg-3">{item.role}</span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </ul>
      </Container>
    </Section>
  );
}

function initials(name: string) {
  const letters = name
    .replace(/[^\p{L}\s]/gu, "")
    .split(/\s+/)
    .filter(Boolean)
    .map((part) => part[0])
    .join("");
  return letters.slice(0, 2).toUpperCase() || "?";
}
