import { Container, Section, SectionHeading } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { SERVICES, SERVICES_INTRO } from "@/config/site";
import { ICONS } from "@/lib/icons";

export function Services() {
  return (
    <Section id="services" aria-labelledby="services-heading">
      <Container>
        <Reveal>
          <SectionHeading id="services-heading" align="start" {...SERVICES_INTRO} />
        </Reveal>
        <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service, i) => {
            const Icon = ICONS[service.icon];
            return (
              <Reveal
                as="li"
                key={service.title}
                delay={(i % 3) * 0.06}
                className="group rounded-2xl border border-border bg-surface p-6 shadow-card transition-colors hover:border-border-strong"
              >
                <span className="grid size-10 place-items-center rounded-xl bg-blue-bg text-blue-ink">
                  <Icon aria-hidden className="size-5" />
                </span>
                <h3 className="mt-5 text-h2 text-fg">{service.title}</h3>
                <p className="mt-2 text-[15px] leading-6 text-fg-2">{service.body}</p>
              </Reveal>
            );
          })}
        </ul>
      </Container>
    </Section>
  );
}
