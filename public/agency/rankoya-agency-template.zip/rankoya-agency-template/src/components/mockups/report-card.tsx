import { EngineBars, SampleChip, ScoreChart, ScoreHeadline } from "@/components/mockups/report-parts";
import { REPORT } from "@/config/site";

/** The hero's sample client report: score, trend and AI engine mentions. */
export function ReportCard() {
  return (
    <div className="rounded-[24px] border border-border bg-surface p-5 text-start shadow-showcase sm:p-7">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-overline text-fg-3">AI visibility score</p>
          <p className="mt-1 text-h3 text-fg">{REPORT.client}</p>
        </div>
        <SampleChip />
      </div>
      <div className="mt-5 flex flex-wrap items-end justify-between gap-2">
        <ScoreHeadline />
        <p className="mb-2 text-[13px] text-fg-3">{REPORT.period}</p>
      </div>
      <ScoreChart className="mt-4" />
      <div className="mt-6 border-t border-border pt-5">
        <p className="mb-4 text-[13px] font-medium text-fg-2">Mentioned in buyer prompts</p>
        <EngineBars />
      </div>
    </div>
  );
}
