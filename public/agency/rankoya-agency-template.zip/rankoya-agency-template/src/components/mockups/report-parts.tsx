import { useId } from "react";
import { ArrowUpRight } from "lucide-react";

import { PlatformIcon } from "@/components/ui/platform-icon";
import { REPORT } from "@/config/site";
import { cn } from "@/lib/cn";
import { PLATFORMS } from "@/lib/platforms";

/** Small "Sample data" chip, so visitors never mistake the mockup for a live client. */
export function SampleChip({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border border-border bg-surface-2 px-2 py-0.5 text-caption text-fg-2",
        className,
      )}
    >
      Sample data
    </span>
  );
}

/** Score plus delta. The delta shows an arrow and a sign, never colour alone. */
export function ScoreHeadline() {
  return (
    <div className="flex items-end gap-3">
      <p className="text-metric-xl text-fg">
        {REPORT.score}
        <span className="text-[20px] text-fg-3">/100</span>
      </p>
      <p className="mb-1.5 inline-flex items-center gap-0.5 rounded-full bg-success-bg px-2 py-0.5 text-[13px] font-medium text-success">
        <ArrowUpRight aria-hidden className="size-3.5" />
        <span className="num">+{REPORT.scoreDelta}</span>
        <span className="sr-only">points</span>
      </p>
    </div>
  );
}

/** Area chart of the visibility score over the report period. */
export function ScoreChart({ className }: { className?: string }) {
  const id = useId();
  const W = 320;
  const H = 120;
  const pad = 6;
  const values = REPORT.trend;
  const min = Math.min(...values) - 8;
  const max = Math.max(...values) + 4;
  const x = (i: number) => pad + (i / (values.length - 1)) * (W - pad * 2);
  const y = (v: number) => H - pad - ((v - min) / (max - min)) * (H - pad * 2);
  const line = values.map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
  const area = `${line} L${x(values.length - 1)},${H} L${x(0)},${H} Z`;

  return (
    <figure className={className}>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="h-auto w-full overflow-visible"
        role="img"
        aria-labelledby={`${id}-title`}
      >
        <title id={`${id}-title`}>
          {`Visibility score from ${values[0]} to ${values[values.length - 1]} over ${REPORT.period.toLowerCase()}`}
        </title>
        <defs>
          <linearGradient id={`${id}-fill`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--chart-you)" stopOpacity="0.22" />
            <stop offset="100%" stopColor="var(--chart-you)" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((f) => (
          <line key={f} x1="0" x2={W} y1={H * f} y2={H * f} stroke="var(--border)" strokeDasharray="3 4" />
        ))}
        <path d={area} fill={`url(#${id}-fill)`} />
        <path
          d={line}
          pathLength={1}
          className="chart-line"
          fill="none"
          stroke="var(--chart-you)"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle
          cx={x(values.length - 1)}
          cy={y(values[values.length - 1])}
          r="4.5"
          fill="var(--surface)"
          stroke="var(--chart-you)"
          strokeWidth="2.5"
        />
      </svg>
      <div aria-hidden className="mt-2 flex justify-between text-caption font-normal text-fg-3">
        {REPORT.months.map((m) => (
          <span key={m}>{m}</span>
        ))}
      </div>
    </figure>
  );
}

/** Mention rate per AI engine, as labelled bars. */
export function EngineBars({ className }: { className?: string }) {
  return (
    <ul className={cn("space-y-3", className)}>
      {REPORT.engines.map((engine) => (
        <li key={engine.id} className="flex items-center gap-3">
          <PlatformIcon id={engine.id} size={22} decorative />
          <span className="w-20 shrink-0 text-[13px] text-fg-2">{PLATFORMS[engine.id].name}</span>
          <span className="h-2 flex-1 overflow-hidden rounded-full bg-surface-2">
            <span className="block h-full rounded-full bg-chart-you" style={{ width: `${engine.mentions}%` }} />
          </span>
          <span className="w-10 text-end num text-[13px] text-fg">{engine.mentions}%</span>
        </li>
      ))}
    </ul>
  );
}

const SOV_COLOURS = ["bg-chart-you", "bg-chart-a", "bg-chart-b", "bg-chart-c"];

/** Share of voice against competitors: one stacked bar plus a legend. */
export function ShareOfVoice({ className }: { className?: string }) {
  return (
    <div className={className}>
      <div aria-hidden className="flex h-3 gap-0.5 overflow-hidden rounded-full">
        {REPORT.shareOfVoice.map((row, i) => (
          <span key={row.name} className={SOV_COLOURS[i % SOV_COLOURS.length]} style={{ width: `${row.value}%` }} />
        ))}
      </div>
      <ul className="mt-4 grid gap-2.5">
        {REPORT.shareOfVoice.map((row, i) => (
          <li key={row.name} className="flex items-center gap-2 text-[13px]">
            <span aria-hidden className={cn("size-2.5 shrink-0 rounded-sm", SOV_COLOURS[i % SOV_COLOURS.length])} />
            <span className={cn("truncate", row.you ? "font-medium text-fg" : "text-fg-2")}>{row.name}</span>
            <span className="ms-auto num text-fg">{row.value}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
