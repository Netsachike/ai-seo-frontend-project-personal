import { SITE } from "@/config/site";
import { cn } from "@/lib/cn";

/**
 * Monogram badge plus agency name. To use your own logo, put the file in
 * /public and replace this markup with <img src="/logo.svg" alt={SITE.name} />.
 */
export function Logo({ className, onDark = false }: { className?: string; onDark?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)} translate="no">
      <span
        aria-hidden
        className="grid size-8 place-items-center rounded-[10px] bg-ink text-[15px] font-semibold text-ink-fg"
      >
        {SITE.monogram}
      </span>
      <span className={cn("text-[17px] font-semibold tracking-[-0.01em]", onDark ? "text-white" : "text-fg")}>
        {SITE.name}
      </span>
    </span>
  );
}
