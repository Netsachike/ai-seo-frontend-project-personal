import { cn } from "@/lib/cn";
import { PLATFORMS, type PlatformId } from "@/lib/platforms";

/** A platform's mark on a white rounded tile, so dark marks stay visible in dark mode. */
export function PlatformIcon({
  id,
  size = 28,
  className,
  decorative = false,
}: {
  id: PlatformId;
  size?: number;
  className?: string;
  /** True when a visible label sits next to the icon. */
  decorative?: boolean;
}) {
  const platform = PLATFORMS[id];
  return (
    <img
      src={platform.icon}
      alt={decorative ? "" : platform.name}
      width={size}
      height={size}
      className={cn("shrink-0 bg-white", className)}
      style={{ borderRadius: Math.round(size * 0.24) }}
    />
  );
}
