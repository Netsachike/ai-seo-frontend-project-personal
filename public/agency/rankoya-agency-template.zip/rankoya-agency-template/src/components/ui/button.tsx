import { cn } from "@/lib/cn";
import { SmartLink } from "@/components/ui/smart-link";

type Variant = "primary" | "secondary" | "ghost" | "inverse";
type Size = "sm" | "md" | "lg" | "icon";

const VARIANTS: Record<Variant, string> = {
  primary: "bg-ink text-ink-fg hover:bg-ink-hover",
  secondary: "border border-border-strong bg-surface text-fg hover:bg-surface-hover",
  ghost: "text-fg-2 hover:bg-surface-2 hover:text-fg",
  /** For the fixed-dark panels: reads the same in both themes. */
  inverse: "bg-white text-[#0e1a33] hover:bg-white/90",
};

const SIZES: Record<Size, string> = {
  sm: "h-9 px-4 text-[14px]",
  md: "h-11 px-5 text-[15px]",
  lg: "h-12 px-6 text-[16px]",
  icon: "size-9",
};

type StyleProps = { variant?: Variant; size?: Size };

function buttonClass({ variant = "primary", size = "md" }: StyleProps = {}) {
  return cn(
    "press inline-flex shrink-0 items-center justify-center gap-2 rounded-full font-medium whitespace-nowrap select-none disabled:pointer-events-none disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0",
    VARIANTS[variant],
    SIZES[size],
  );
}

/** A link styled as a button. Most CTAs navigate, so this is the common case. */
export function ButtonLink({
  className,
  variant,
  size,
  ...props
}: Omit<React.ComponentProps<"a">, "href"> & { href: string } & StyleProps) {
  return <SmartLink className={cn(buttonClass({ variant, size }), className)} {...props} />;
}

export function Button({
  className,
  variant,
  size,
  type = "button",
  ...props
}: React.ComponentProps<"button"> & StyleProps) {
  return <button type={type} className={cn(buttonClass({ variant, size }), className)} {...props} />;
}
