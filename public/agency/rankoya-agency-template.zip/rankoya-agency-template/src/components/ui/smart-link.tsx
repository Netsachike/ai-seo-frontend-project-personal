import { Link } from "react-router";

/**
 * Internal routes ("/pricing", "/#faq") go through the router; in-page anchors,
 * mailto links and external URLs stay plain anchors.
 */
export function SmartLink({ href, ...props }: Omit<React.ComponentProps<"a">, "href"> & { href: string }) {
  if (href.startsWith("/")) return <Link to={href} {...props} />;
  const external = /^https?:\/\//.test(href);
  return <a href={href} {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})} {...props} />;
}
