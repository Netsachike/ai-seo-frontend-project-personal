import { cn } from "@/lib/cn";

/**
 * Fades and lifts its children in the first time they scroll into view.
 * useReveal (mounted once in the layout) and CSS do the work; content stays
 * visible without JavaScript and under reduced motion.
 */
export function Reveal({
  children,
  className,
  delay = 0,
  y = 24,
  as: Component = "div",
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  y?: number;
  as?: "div" | "li";
}) {
  const style = {
    "--reveal-delay": `${Math.round(delay * 1000)}ms`,
    "--reveal-y": `${y}px`,
  } as React.CSSProperties;
  return (
    <Component className={cn("reveal", className)} style={style}>
      {children}
    </Component>
  );
}
