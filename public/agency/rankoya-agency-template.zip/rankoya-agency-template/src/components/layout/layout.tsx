import { Outlet } from "react-router";

import { Footer } from "@/components/layout/footer";
import { Header } from "@/components/layout/header";
import { useReveal } from "@/hooks/use-reveal";
import { useScrollToHash } from "@/hooks/use-scroll-to-hash";

export function Layout() {
  useScrollToHash();
  useReveal();
  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#main"
        className="sr-only z-50 rounded-full bg-ink px-4 py-2 text-ink-fg focus:not-sr-only focus:fixed focus:top-3 focus:left-3"
      >
        Skip to content
      </a>
      <Header />
      <main id="main" className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
