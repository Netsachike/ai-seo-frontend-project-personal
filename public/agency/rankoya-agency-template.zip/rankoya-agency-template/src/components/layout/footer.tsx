import { Link } from "react-router";

import { Container } from "@/components/ui/container";
import { Logo } from "@/components/ui/logo";
import { SmartLink } from "@/components/ui/smart-link";
import { FOOTER, SITE } from "@/config/site";

export function Footer() {
  return (
    <footer className="border-t border-border bg-surface">
      <Container className="grid gap-12 py-14 lg:grid-cols-[1.2fr_2fr] lg:gap-16">
        <div className="max-w-sm">
          <Link to="/" aria-label={`${SITE.name} home`} className="inline-flex rounded-md">
            <Logo />
          </Link>
          <p className="mt-4 text-[15px] leading-6 text-fg-2">{SITE.tagline}</p>
          <ul className="mt-6 flex flex-wrap gap-2">
            {SITE.socials.map((social) => (
              <li key={social.label}>
                <SmartLink
                  href={social.href}
                  className="inline-flex h-9 items-center rounded-full border border-border px-3.5 text-[14px] font-medium text-fg-2 transition-colors hover:border-border-strong hover:text-fg"
                >
                  {social.label}
                </SmartLink>
              </li>
            ))}
          </ul>
        </div>

        <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
          {FOOTER.columns.map((column) => (
            <nav key={column.title} aria-label={column.title}>
              <p className="text-h3 text-fg">{column.title}</p>
              <ul className="mt-4 space-y-3">
                {column.links.map((link) => (
                  <li key={link.label}>
                    <SmartLink href={link.href} className="text-[14px] text-fg-2 transition-colors hover:text-fg">
                      {link.label}
                    </SmartLink>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>
      </Container>

      <Container className="flex flex-col gap-2 border-t border-border py-6 text-[13px] text-fg-3 sm:flex-row sm:items-center sm:justify-between">
        <p>
          © <span className="num">{new Date().getFullYear()}</span> {SITE.name}. All rights reserved.
        </p>
        {SITE.poweredByRankoya && (
          <p>
            Visibility data by{" "}
            <a
              href="https://rankoya.uk"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-fg-2 hover:text-fg hover:underline"
            >
              Rankoya
            </a>
          </p>
        )}
      </Container>
    </footer>
  );
}
