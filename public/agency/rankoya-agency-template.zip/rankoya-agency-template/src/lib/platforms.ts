import chatgpt from "@/assets/platforms/chatgpt.png";
import claude from "@/assets/platforms/claude.png";
import gemini from "@/assets/platforms/gemini.png";
import googleAnalytics from "@/assets/platforms/google-analytics.png";
import googleMaps from "@/assets/platforms/google-maps.png";
import google from "@/assets/platforms/google.png";
import perplexity from "@/assets/platforms/perplexity.png";
import searchConsole from "@/assets/platforms/search-console.png";
import shopify from "@/assets/platforms/shopify.png";
import webflow from "@/assets/platforms/webflow.png";
import wix from "@/assets/platforms/wix.png";
import wordpress from "@/assets/platforms/wordpress.png";

export const PLATFORMS = {
  google: { name: "Google", icon: google },
  "google-maps": { name: "Google Maps", icon: googleMaps },
  chatgpt: { name: "ChatGPT", icon: chatgpt },
  claude: { name: "Claude", icon: claude },
  gemini: { name: "Gemini", icon: gemini },
  perplexity: { name: "Perplexity", icon: perplexity },
  "search-console": { name: "Search Console", icon: searchConsole },
  "google-analytics": { name: "Google Analytics", icon: googleAnalytics },
  wordpress: { name: "WordPress", icon: wordpress },
  shopify: { name: "Shopify", icon: shopify },
  webflow: { name: "Webflow", icon: webflow },
  wix: { name: "Wix", icon: wix },
} as const;

export type PlatformId = keyof typeof PLATFORMS;
