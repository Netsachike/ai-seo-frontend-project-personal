import {
  Briefcase,
  Code2,
  FileText,
  LineChart,
  MapPin,
  Radar,
  ShoppingBag,
  Stethoscope,
  Store,
  Users,
  UtensilsCrossed,
  Wrench,
  type LucideIcon,
} from "lucide-react";

import type { IconName } from "@/config/site";

/** Maps the icon names used in src/config/site.ts to Lucide icons. */
export const ICONS: Record<IconName, LucideIcon> = {
  radar: Radar,
  fileText: FileText,
  wrench: Wrench,
  mapPin: MapPin,
  lineChart: LineChart,
  users: Users,
  store: Store,
  shoppingBag: ShoppingBag,
  code: Code2,
  briefcase: Briefcase,
  utensils: UtensilsCrossed,
  stethoscope: Stethoscope,
};
