import { useEffect } from "react";

import { CaseStudies } from "@/components/sections/case-studies";
import { Comparison } from "@/components/sections/comparison";
import { Contact } from "@/components/sections/contact";
import { Faq } from "@/components/sections/faq";
import { Hero } from "@/components/sections/hero";
import { Industries } from "@/components/sections/industries";
import { PricingPreview } from "@/components/sections/pricing-preview";
import { Process } from "@/components/sections/process";
import { ReportSection } from "@/components/sections/report-section";
import { Services } from "@/components/sections/services";
import { Stats } from "@/components/sections/stats";
import { Testimonials } from "@/components/sections/testimonials";
import { TrackedStrip } from "@/components/sections/tracked-strip";
import { SITE } from "@/config/site";

/** Reorder, remove or duplicate sections here. */
export default function Home() {
  useEffect(() => {
    document.title = `${SITE.name} | Search and AI visibility agency`;
  }, []);

  return (
    <>
      <Hero />
      <TrackedStrip />
      <Services />
      <Comparison />
      <Process />
      <ReportSection />
      <CaseStudies />
      <Industries />
      <Stats />
      <Testimonials />
      <PricingPreview />
      <Faq />
      <Contact />
    </>
  );
}
