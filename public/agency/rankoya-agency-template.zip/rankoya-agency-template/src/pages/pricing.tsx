import { Fragment, useEffect } from "react";
import { Check, Minus } from "lucide-react";

import { Contact } from "@/components/sections/contact";
import { Faq } from "@/components/sections/faq";
import { PlanCards } from "@/components/sections/plan-cards";
import { ButtonLink } from "@/components/ui/button";
import { Container, Section } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { PLAN_COMPARISON, PLANS, PRICING, SITE } from "@/config/site";
import { cn } from "@/lib/cn";

export default function Pricing() {
  useEffect(() => {
    document.title = `Pricing | ${SITE.name}`;
  }, []);

  return (
    <>
      <section aria-labelledby="pricing-page-heading" className="relative isolate overflow-hidden">
        <div
          aria-hidden
          className="absolute inset-0 -z-10 bg-grid [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,black,transparent)] opacity-70"
        />
        <Container className="pt-14 pb-16 text-center sm:pt-20">
          <p className="text-overline text-blue">{PRICING.overline}</p>
          <h1 id="pricing-page-heading" className="mx-auto mt-3 max-w-3xl text-hero text-fg">
            {PRICING.title}
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-lead text-fg-2">{PRICING.lead}</p>
          <div className="mt-12 text-start">
            <PlanCards />
          </div>
        </Container>
      </section>

      <Section aria-labelledby="compare-heading" className="border-t border-border bg-surface">
        <Container>
          <Reveal>
            <h2 id="compare-heading" className="text-center text-section text-fg">
              {PRICING.compareLabel}
            </h2>
          </Reveal>
          <Reveal className="mt-12 overflow-x-auto rounded-2xl border border-border">
            <table className="w-full min-w-[640px] border-collapse text-start text-[14px]">
              <thead>
                <tr className="bg-bg">
                  <th scope="col" className="w-2/5 p-4 text-start font-medium text-fg-2">
                    <span className="sr-only">Feature</span>
                  </th>
                  {PLANS.map((plan) => (
                    <th
                      key={plan.id}
                      scope="col"
                      className={cn("p-4 text-start text-h3", plan.featured ? "text-blue" : "text-fg")}
                    >
                      {plan.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {PLAN_COMPARISON.map((group) => (
                  <Fragment key={group.group}>
                    <tr className="border-t border-border bg-surface-2">
                      <th
                        scope="colgroup"
                        colSpan={PLANS.length + 1}
                        className="px-4 py-2.5 text-start text-overline text-fg-2"
                      >
                        {group.group}
                      </th>
                    </tr>
                    {group.rows.map((row) => (
                      <tr key={row.label} className="border-t border-border">
                        <th scope="row" className="p-4 text-start font-normal text-fg">
                          {row.label}
                        </th>
                        {row.values.map((value, i) => (
                          <td key={PLANS[i].id} className="p-4 text-fg">
                            <Cell value={value} />
                          </td>
                        ))}
                      </tr>
                    ))}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </Reveal>

          <Reveal className="mt-10 flex flex-col items-start gap-4 rounded-2xl border border-border bg-bg p-6 sm:flex-row sm:items-center sm:justify-between sm:p-8">
            <div>
              <h3 className="text-h2 text-fg">{PRICING.customTitle}</h3>
              <p className="mt-1 text-[15px] text-fg-2">{PRICING.customBody}</p>
            </div>
            <ButtonLink href={SITE.bookingUrl} variant="secondary">
              {PRICING.customCta}
            </ButtonLink>
          </Reveal>
        </Container>
      </Section>

      <Faq className="border-t-0 bg-bg" />
      <Contact />
    </>
  );
}

function Cell({ value }: { value: string | boolean }) {
  if (value === true)
    return (
      <>
        <Check aria-hidden className="size-4 text-blue" strokeWidth={2.5} />
        <span className="sr-only">Included</span>
      </>
    );
  if (value === false)
    return (
      <>
        <Minus aria-hidden className="size-4 text-fg-3" />
        <span className="sr-only">Not included</span>
      </>
    );
  return <span className={/^[\d.,]+$/.test(value) ? "num" : undefined}>{value}</span>;
}
