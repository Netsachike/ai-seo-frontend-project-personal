import { ButtonLink } from "@/components/ui/button";
import { Container } from "@/components/ui/container";

export default function NotFound() {
  return (
    <Container className="flex flex-col items-center py-32 text-center">
      <p className="num text-overline text-blue">404</p>
      <h1 className="mt-3 text-section text-fg">This page doesn't exist</h1>
      <p className="mt-4 max-w-md text-lead text-fg-2">The link may be old, or the page may have moved.</p>
      <ButtonLink href="/" className="mt-8">
        Back to home
      </ButtonLink>
    </Container>
  );
}
